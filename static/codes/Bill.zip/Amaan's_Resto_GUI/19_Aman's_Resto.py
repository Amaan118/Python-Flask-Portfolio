from tkinter import *
import datetime
import tkinter.messagebox as tmsg


def reset():
    customer_name.set("")
    crispy_roll.set(0)
    crispy_bun.set(0)
    cola.set(0)
    fries.set(0)
    bill.set(0.0)
    cgst.set(0.0)


def create_frame(name, variable):
    item = Frame(window, width=1100, height=90)
    item.pack(pady=10)
    Label(item, text=f"{name} : ", font="lucida 15 bold").pack(side=LEFT)
    Entry(item, textvariable=variable, font="lucida 15 bold").pack(side=LEFT)


def order():
    tbill, tcgst, tsgst = 0, 0, 0
    tbill = (crispy_roll.get()*90) + (crispy_bun.get()*90) + \
        (cola.get()*20) + (fries.get()*30)

    tcgst = tbill * 0.05
    tbill += tcgst
    
    bill.set(tbill)
    cgst.set(tcgst)
    tmsg.showinfo(title="Order Booked !! ",
					message=f"Order Number : {order_num.get()} \nReciepent Name : {customer_name.get()} \nBill : Rs. {tbill}", icon="info")
    
    with open("Orders.txt", "a") as f:
        f.write(f"Date : {today.strftime('%d-%m-%Y')} \tTime : {today.strftime('%H-%M-%S')}")
        f.write(f"\nOrder Number : {order_num.get()}")
        f.write(f"\nName : {customer_name.get()}")
        f.write(f"\nCrispy Roll : {crispy_roll.get()}\t Crispy Bun : {crispy_bun.get()}\t Cola : {cola.get()}\t Fries : {fries.get()}")
        f.write(f"\nBill : {bill.get()} \n\n")
        
    order_num.set(order_num.get() + 1)


def fixed_frame(entry_name, name, variable):
    item = Frame(window, width=1100, height=90)
    item.pack(pady=10)
    Label(item, text=f"{name} : ", font="lucida 15 bold").pack(side=LEFT)
    entry_name = Entry(item, textvariable=variable,
                       state=DISABLED, font="lucida 15 bold")
    entry_name.pack(side=LEFT)


window = Tk()
window.geometry("600x600")
window.maxsize(700, 700)
window.minsize(600, 600)

Label(window, text="Welcome To Amaan's Resto", font="lucida 15 bold",
      fg="orange", bg="black").pack(fill=X)

today = datetime.datetime.now()
Label(window, text=f"Date : {today.strftime('%d-%m-%Y')} \tTime : {today.strftime('%H-%M-%S')}",
      font="lucida 15 bold", fg="orange", bg="black").pack(fill=X)

crispy_roll = IntVar()
crispy_bun = IntVar()
cola = IntVar()
fries = IntVar()
customer_name = StringVar()

bill = IntVar()
bill.set(0.0)
cgst = IntVar()
cgst.set(0.0)
order_num = IntVar()
order_num.set(1)

fixed_frame("order_screen", "Order Number", order_num)

create_frame("Name", customer_name)
create_frame("Crispy Roll", crispy_roll)
create_frame("Crispy Bun", crispy_bun)
create_frame("Coca Cola ", cola)
create_frame("French Fries", fries)

fixed_frame("bill_screen", "Bill", bill)
fixed_frame("cgst_screen", "CGST", cgst)

f = Frame(window, width=1100, height=90)
Button(f, text="Order", font="lucida 15 bold",
       command=order, padx=20, relief=RAISED).pack(padx=15, side=LEFT)
Button(f, text="Reset", font="lucida 15 bold",
       command=reset, padx=20, relief=RAISED).pack(padx=15, side=LEFT)
Button(f, text="Exit", font="lucida 15 bold",
       command=quit, padx=20, relief=RAISED).pack(padx=15, side=LEFT)
f.pack(pady=30)

window.mainloop()
