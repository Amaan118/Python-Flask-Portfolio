from tkinter import*
import tkinter.messagebox as tmsg
from tkinter.filedialog import askopenfilename, asksaveasfilename
import os


def new():
    global textFile
    window.title("Untitled - Notepad")
    textFile = None
    textArea.delete(1.0, END)

def openFile():
    global textFile
    textFile = askopenfilename(defaultextension=".txt", filetypes=[("All Files" , "*.*"), ("Text Documents", "*.txt"), ("Python File", "*.py")])
    
    if textFile=="":
        textFile = None
        
    else:
        window.title(f"{os.path.basename(textFile)} - Notepad")
        textArea.delete(1.0, END)
        with open(textFile, "r") as f:
            data = f.read()
            
        textArea.insert(1.0, data)

def save():
    global textFile
    if textFile == None:
        textFile = asksaveasfilename(initialfile="Untitled.txt", defaultextension=".txt", filetypes=[("All Files" , "*.*"), ("Text Documents", "*.txt"), ("Python File", "*.py")])
        
        if textFile=="":
            textFile = None
        
        else:
            with open(textFile, "w") as f:
                f.write(textArea.get(1.0, END))
                
                
            window.title(f"{os.path.basename(textFile)} - Notepad")
            
    else:
        with open(textFile, "w") as f:
            f.write(textArea.get(1.0, END))
                
def save_as():
    global textFile
    if textFile == None:
        textFile = asksaveasfilename(initialfile="Untitled.txt", defaultextension=".txt", filetypes=[("Text Documents", "*.txt"), ("Python File", "*.py"), ("C File", "*.c"), ("HTML File", "*.html"), ("Java File", "*.java")])
        
        if textFile=="":
            textFile = None
        
        else:
            with open(textFile, "w") as f:
                f.write(textArea.get(1.0, END))
                
                
            window.title(f"{os.path.basename(textFile)} - Notepad")
            
    else:
        with open(textFile, "w") as f:
            f.write(textArea.get(1.0, END))

def cut():
    textArea.event_generate("<<Cut>>")

def copy():
    textArea.event_generate("<<Copy>>")

def paste():
    textArea.event_generate("<<Paste>>")
    
def undo():
    textArea.event_generate("<<Undo>>")

def redo():
    textArea.event_generate("<<Redo>>")
    
def select_all():
    textArea.tag_add("sel", 1.0, END)
    
def deselect_all():
    textArea.tag_remove("sel", 1.0, END)

def about():
    tmsg.showinfo(title="About", message="This is a Basic Notepad \nBy Amaan Khan")

def end():
    msg = tmsg.askyesno(title="Exit ", message="Do you wan't to Quit ?", icon="info")
    if msg:
        window.destroy()

window = Tk()
window.geometry("500x500")
window.title("Untitled - Notepad")
textFile = None

scrl = Scrollbar(window)
scrl.pack(side=RIGHT, fill=Y)

textArea = Text(window, font="lucida 12", yscrollcommand=scrl.set)
textArea.pack(expand=True, fill=BOTH)

main = Menu(window)
file = Menu(main, tearoff=0)
file.add_command(label="New", command=new)
file.add_command(label="Open", command=openFile)
file.add_command(label="Save", command=save)
file.add_command(label="Save as", command=save_as)
file.add_separator()
file.add_command(label="Exit", command=end)
main.add_cascade(label="File", menu=file)

edit = Menu(main, tearoff=0)
edit.add_command(label="Cut", command=cut, accelerator="Ctrl+X")
edit.add_command(label="Copy", command=copy, accelerator="Ctrl+C")
edit.add_command(label="Paste", command=paste, accelerator="Ctrl+V")
edit.add_separator()
edit.add_command(label="Undo", command=undo, accelerator="Ctrl+Z")
edit.add_command(label="Redo", command=redo, accelerator="Ctrl+Y")
edit.add_command(label="Select All", command=select_all, accelerator="Ctrl+A")
edit.add_command(label="Deselect All", command=deselect_all)
main.add_cascade(label="Edit", menu=edit)


main.add_command(label="About", command=about)
window.config(menu=main)

scrl.config(command=textArea.yview)

window.mainloop()