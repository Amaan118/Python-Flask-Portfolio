import random
import datetime


def help():
    print('''
          Hangman Game : 
          You Have to Guess the word Chosen by Computer in given number of lives or you will Hang!!
          
          For Amateur Difficulty Number of Lives for Player Will be : size of word + 7
          For Medium Difficulty Number of Lives for Player Will be : size of word + 5
          For Advanced Difficulty Number of Lives for Player Will be : size of word + 3
          
          Developer : Amaan Khan
          E-mail : amankhan@hangman.com
          
          ''')
    exit()


def msg(char):
    print("\nWord To Guess : ", end='')
    for i in char:
        print(f"{i.upper()}", end='')


def alive():
    print(f'''        
              \\ O /
                |
                |         HOORRAY !!!!
               / \\
                
              Player Saved !!!
              
              ''')

    with open("Hangman_Data.txt", "a") as f:
        today = datetime.datetime.now().strftime("%d-%m-%Y")
        f.write(f"Date : {today} ")
        f.write(f"\nDifficulty : {difficulty}")
        f.write(f"\nWord To Guess : {word.upper()}")
        f.write("\nResult : Player Saved !!")
        f.write("\n\n")


def dead():
    print(f'''
\n\n-----------------
                |
                O
               /|\\
                |         HANGED !!!!
               / \\
                
            
            Word : {word.upper()}''')

    with open("Hangman_Data.txt", "a") as f:
        today = datetime.datetime.now().strftime("%d-%m-%Y")
        f.write(f"Date : {today} ")
        f.write(f"\nDifficulty : {difficulty}")
        f.write(f"\nWord To Guess : {word.upper()}")
        f.write("\nResult : Player Hanged !!")
        f.write("\n\n")


def hangman(lives):
    while lives != 0:
        print(f"\n\nLives : {lives}")
        lives -= 1

        while True:
            user = input("\nEnter Character : ").lower()
            if user not in used_char:
                used_char.append(user)
                print(f"Used Characters : {used_char}")
                break
            else:
                print(f"{user} letter already used ")

        for ind, val in enumerate(word):
            if user == val:
                ans[ind] = str(' ') + user + str(' ')

        msg(''.join(ans))
        string = ''.join(ans)

        correct = string.replace(" ", "")
        if word == correct:
            print(f"\n\nYou Guessed word {word.upper()} Correctly\n")
            alive()
            exit()

    dead()


if __name__ == '__main__':
    with open("12_Words.txt", "r") as f:
        data = f.read()

    words = data.split(',')
    word = random.choice(words)

    ans, used_char = [], []

    for i in range(len(word)):
        ans.append(' _ ')

    choice = int(input('''
            Choose Difficulty Level : 
            1. Amateur Level 
            2. Medium Level 
            3. Advanced Level 
            4. Help 
            
            Enter Choice : '''))

    if choice == 4:
        help()

    if choice == 1:
        lives = len(word) + 7
        difficulty = "Amateur"
    elif choice == 2:
        lives = len(word) + 5
        difficulty = "Medium"
    elif choice == 3:
        lives = len(word) + 3
        difficulty = "Advanced"
        

    msg(ans)
    hangman(lives)