import pandas as pd
import datetime
import smtplib

GMAIL_ID = 'user@gmail.com'
GMAIL_PASSWORD = 'password'


def sendEmail(to, name, tod):
    body = f'''
Date : {tod.strftime("%d-%m-%Y")}
To {to},
    Happy Birthday, {name}
        Dear ,{name} Very Very Happy Birthday to You, May God bless you, 
        Have a blast & anjoy your day.
        
From Your's Truly 
Amaan Khan'''

    s = smtplib.SMTP('smtp.gmail.com', 587)
    s.starttls()
    s.login(GMAIL_ID, GMAIL_PASSWORD)
    s.sendmail(GMAIL_ID, to,body)
    s.quit()


df = pd.read_excel("Data.xlsx")
today = datetime.datetime.now().strftime("%d-%m")
year_now = datetime.datetime.now().strftime("%Y")

for ind, item in df.iterrows():
    bday = item['Birthday'].strftime("%d-%m")

    if (today == bday) and (year_now == str(item['Year'])):
        sendEmail(item['Email'], item['Name'], item['Birthday'])
        yr = df.loc[ind, 'Year']
        df.loc[ind, 'Year'] = str(int(yr) + 1)

df.to_excel("Data.xlsx", index=False)
