from tkinter import *
import tkinter.messagebox as tmsg
import math
import time


def end():
    msg = tmsg.askquestion(title="Exit Calculator",
                           message="Do You Wan't to Quit \nAmaan's Calculator ?", icon="warning")
    if msg == "yes":
        global inp
        inp.set("By Amaan Khan")
        screen.update()
        time.sleep(1)
        window.destroy()


def reset():
    global inp
    inp.set("Clearing Memory.......")
    screen.update()
    time.sleep(1)
    inp.set("History Cleared !!! ")
    screen.update()
    time.sleep(1)
    inp.set("")
    screen.update()


def click(event):
    global inp
    value = event.widget.cget("text")

    if value == "=":
        try:
            answer = eval(inp.get())
            inp.set(answer)
            screen.update()

        except:
            inp.set("Error ")
            screen.update()

    elif value == "!":
        numb = []
        string = inp.get()
        if string == "":
            inp.set("Error")
        else:
            for char in string:
                if char.isdigit():
                    numb.append(char)

            n = "".join(numb)
            n = int(n)
            ans = math.factorial(n)
            inp.set(ans)
        screen.update()

    else:
        inp.set(inp.get() + value)
        screen.update()


def screen_clear():
    inp.set("")
    screen.update()
    


window = Tk()
window.geometry("350x400")
window.title("Calculator - Amaan Khan")
number = ["1", "2", "3", "+", "4", "5", "6", "-", "7",
          "8", "9", "*", "0", "00", ".", "/", "**", "!"]
window.wm_iconbitmap("calculator.ico")

background, btn_color = "black", "cyan"
window.config(bg=background)

main = Menu(window)
custom = Menu(main, tearoff=0)
custom.add_command(label="Reset Memory", command=reset)
custom.add_command(label="Exit Calculator", command=end)
window.config(menu=main)
main.add_cascade(label="Customise", menu=custom)

inp = StringVar()
inp.set("")
screen = Entry(window, textvar=inp, font="lucida 15 bold")
screen.pack()

f = Frame(window, bg=background)
f.pack(pady=10)
j = 0

for num in number:
    j += 1
    btn = Button(f, text=num, font="lucida 10 bold", width=3,
                 relief=GROOVE, bg=btn_color, fg=background, padx=15, pady=5)
    btn.bind("<Button-1>", click)
    btn.pack(side=LEFT, padx=5)
    if j % 4 == 0:
        f = Frame(window, bg=background)
        f.pack(pady=10)

btn = Button(f, text="=", font="lucida 10 bold", width=3,
             relief=GROOVE, bg=btn_color, fg=background, padx=50, pady=5)
btn.bind("<Button-1>", click)
btn.pack(side=LEFT, padx=5)

f = Frame(window, bg=background)
f.pack()
Button(f, text="C", command=screen_clear, font="lucida 10 bold", width=5, bg=btn_color, fg=background, relief=GROOVE, padx=15, pady=5).pack(side=LEFT, padx=10)
Button(f, text="Exit", command=end, font="lucida 10 bold", width=5, bg=btn_color, fg=background, relief=GROOVE, padx=15, pady=5).pack(side=LEFT)

window.mainloop()
