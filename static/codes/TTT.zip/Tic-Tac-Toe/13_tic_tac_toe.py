def board(blank):
    print(f'''
			| {blank[0]} | {blank[1]} | {blank[2]} |                        | 1 | 2 | 3 |
		     ------------------                    ------------------     
			| {blank[3]} | {blank[4]} | {blank[5]} |                        | 4 | 5 | 6 |
		     ------------------                    ------------------
			| {blank[6]} | {blank[7]} | {blank[8]} |                        | 7 | 8 | 9 |
   
   ''')


def help():
    print('''
	TIC-TAC-TOE
	How To Play ?
	Choose either X or O and put it inside the 3x3 Cube if You Align Your Option in a Straight Line You Win !! ''')

    exit()


def player1(opt1):
    num = int(input(f"\t{name1} Enter Box Number to Put {opt1} : "))

    if (num in player1_tiles) or (num in player2_tiles) or (num > 9):
        player1(opt1)

    else:
        player1_tiles.append(num)
        blank[num-1] = opt1


def player2(opt2):
    num = int(input(f"\t{name2} Enter Box Number to Put {opt2} : "))

    if (num in player1_tiles) or (num in player2_tiles) or (num > 9):
        player2(opt2)

    else:
        player2_tiles.append(num)
        blank[num-1] = opt2


def result(pt1, pt2):
    win_combo = [(1, 5, 9), (1, 2, 3), (1, 4, 7), (3, 6, 9),
                 (3, 5, 7), (4, 5, 6), (7, 8, 9), (2, 5, 8)]
    res = 0
    for i in win_combo:
        for j in i:
            if j in pt1:
                res += 1

        if res == 3:
            print(f"\n\tCongrats {name1} Wins !!!! \n")
            exit()
        res = 0

    for i in win_combo:
        for j in i:
            if j in pt2:
                res += 1

        if res == 3:
            print(f"\n\tCongrats {name2} Wins !!!! \n")
            exit()
        res = 0


if __name__ == '__main__':
    filled, blank, player1_tiles, player2_tiles = [], [], [], []
    for i in range(9):
        blank.append(" ")

    name1 = input("\n\tEnter Player1's Name : ")
    name2 = input("\tEnter Player2's Name : ")

    user = int(input(f'''
        {name1} : 
        1. Choose X
        2. Choose O
        3. Help 
        
        Enter Choice : '''))

    if user == 1:
        opt1 = 'X'
        opt2 = 'O'
    elif user == 2:
        opt1 = 'O'
        opt2 = 'X'
    else:
        help()

    print(f'''
          {name1} Chose {opt1}
          {name2} was given {opt2}
          ''')

    print('''
          Let's Start : ''')
    board(blank)

    player1(opt1)
    board(blank)
    player2(opt2)
    board(blank)

    player1(opt1)
    board(blank)
    player2(opt2)
    board(blank)

    player1(opt1)
    board(blank)
    result(player1_tiles, player2_tiles)

    player2(opt2)
    board(blank)
    result(player1_tiles, player2_tiles)

    player1(opt1)
    board(blank)
    result(player1_tiles, player2_tiles)

    player2(opt2)
    board(blank)
    result(player1_tiles, player2_tiles)

    player1(opt1)
    board(blank)
    result(player1_tiles, player2_tiles)

    print(f'''
          It's a Draw !!! 
          Great Play {name1} & {name2}
          ''')
