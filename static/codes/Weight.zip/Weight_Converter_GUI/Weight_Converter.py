from tkinter import *


def radio(name, var):
	global val, f
	Radiobutton(f, text=name, value=val, variable=var, font="lucida 10").pack()
	val += 1
	
	
def convert():
	global unit, unit2, screen, weight, converted
	wt = weight.get()
	if unit.get() == 1:
		if unit2.get() == 2:
			wt *= 10**3
		elif unit2.get() == 3:
			wt *= 10**6
		elif unit2.get() == 4:
			wt *= 10**9
		elif unit2.get() == 5:
			wt *= 10**(-3)
		elif unit2.get() == 6:
			wt *= 2.205
		elif unit2.get() == 7:
			wt *= 35.274
	
	elif unit.get() == 2:
		if unit2.get() == 1:
			wt /= 10**3
		elif unit2.get() == 3:
			wt *= 10**3
		elif unit2.get() == 4:
			wt *= 10**6
		elif unit2.get() == 5:
			wt /= 10**6
		elif unit2.get() == 6:
			wt /= 454
		elif unit2.get() == 7:
			wt /= 28.35
	
	elif unit.get() == 3:
		if unit2.get() == 1:
			wt /= 10**6
		elif unit2.get() == 2:
			wt /= 10**3
		elif unit2.get() == 4:
			wt *= 10**3
		elif unit2.get() == 5:
			wt /= 10**9
		elif unit2.get() == 6:
			wt /= 453592
		elif unit2.get() == 7:
			wt /= 28325
			
	elif unit.get() == 4:
		if unit2.get() == 1:
			wt /= 10**9
		elif unit2.get() == 2:
			wt /= 10**6
		elif unit2.get() == 3:
			wt /= 10**3
		elif unit2.get() == 5:
			wt /= 10**12
		elif unit2.get() == 6:
			wt /= 4.536*10**8
		elif unit2.get() == 7:
			wt /= 2.835*10**7
			
	elif unit.get() == 5:
		if unit2.get() == 1:
			wt *= 10**3
		elif unit2.get() == 2:
			wt *= 10**6
		elif unit2.get() == 3:
			wt *= 10**9
		elif unit2.get() == 4:
			wt *= 10**12
		elif unit2.get() == 6:
			wt *= 2204.62
		elif unit2.get() == 7:
			wt *= 35274
			
	elif unit.get() == 6:
		if unit2.get() == 1:
			wt /= 2.205
		elif unit2.get() == 2:
			wt *= 454
		elif unit2.get() == 3:
			wt *= 453592
		elif unit2.get() == 4:
			wt *= 4.536*10**8
		elif unit2.get() == 5:
			wt /= 2204.62
		elif unit2.get() == 7:
			wt *= 16
			
	elif unit.get() == 7:
		if unit2.get() == 1:
			wt /= 35.274
		elif unit2.get() == 2:
			wt *= 28.35
		elif unit2.get() == 3:
			wt *= 28325
		elif unit2.get() == 4:
			wt *= 2.835*10**7
		elif unit2.get() == 5:
			wt /= 35274
		elif unit2.get() == 6:
			wt /= 16
	
	converted.set(wt)
	screen.update()
		

window = Tk()
window.title("Weight Converter")
Label(window, text="Weight Converter", font="lucida 10 bold italic", bg="black", fg="white").pack(fill=X)

unit = IntVar()
unit.set(1)
val = 1
f = Frame(window)
Label(f, text="Select Unit of Weight: ", font="lucida 10 bold").pack()
radio("Kilogram (kg)", unit)
radio("Gram (gm)", unit)
radio("Milligram (mg)", unit)
radio("Microgram (μg)", unit)
radio("Tonne (t)", unit)
radio("Pound (£)", unit)
radio("Ounce (oz)", unit)
f.pack(pady=20)


weight = DoubleVar()
weight.set(1.0)
f = Frame(window)
Label(f, text="Enter Weight : ", font="lucida 10 bold").pack(side=LEFT)
Entry(f, textvariable=weight, font="lucida 10 bold").pack()
f.pack(pady=20)


unit2 = IntVar()
unit2.set(1)
val = 1
f = Frame(window)
Label(f, text="Select Unit of Conversion: ", font="lucida 10 bold").pack()
radio("Kilogram (kg)", unit2)
radio("Gram (gm)", unit2)
radio("Milligram (mg)", unit2)
radio("Microgram (μg)", unit2)
radio("Tonne (t)", unit2)
radio("Pound (£)", unit2)
radio("Ounce (oz)", unit2)
f.pack(pady=20)


converted = DoubleVar()
f = Frame(window)
Label(f, text="Converted Weight : ", font="lucida 10 bold").pack(side=LEFT)
screen = Entry(f, textvariable=converted, font="lucida 10 bold", state=DISABLED)
screen.pack()
f.pack(pady=30)


Button(window, text="Convert", command=convert, width=5, font="lucida 10 bold").pack(pady=20)

Button(window, text="Exit", font="lucida 10 bold", command=quit, width=5).pack()
window.mainloop()